ifconfig gbe3 10.9.123.3 netmask 255.255.0.0
#route add default gw 10.9.0.27 dev gbe3

ifconfig gbe4 10.9.123.4 netmask 255.255.0.0
