#ifndef CLOUD_WLAN_DB_CMD_PARSER_H_
#define CLOUD_WLAN_DB_CMD_PARSER_H_


extern u32 cw_db_cmd_branch(u32 type, s8 *src, s8 *dest, u32 *res_len);


#endif
