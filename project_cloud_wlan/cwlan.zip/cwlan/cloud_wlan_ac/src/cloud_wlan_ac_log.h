#ifndef CLOUD_WLAN_AC_LOG_H_
#define CLOUD_WLAN_AC_LOG_H_


extern u32 cw_ac_log_init();


#endif
